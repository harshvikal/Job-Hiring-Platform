from django.db import models
from django.contrib.auth.models import User
from hr.models import CandidateApplications , JobPost
# Create your models here.


class MyApplyJobList(models.Model):
    user = models.ForeignKey(to=User,on_delete=models.CASCADE)
    job = models.OneToOneField(to=CandidateApplications,on_delete=models.CASCADE)
    dateYouApply = models.DateTimeField(auto_now_add=True)


class IsSortList(models.Model):
    user = models.ForeignKey(to=User,on_delete=models.CASCADE)
    job = models.OneToOneField(to=JobPost,on_delete=models.CASCADE)
    dateYouApply = models.DateTimeField(auto_now_add=True)
